# Diejou Skins Pack

Este pack usa aspects cortos con la feature skin.

Formato recomendado:

```mcfunction
/pokegive <pokemon> skin=<skin>
/pokegiveother <jugador> <pokemon> skin=<skin>
/pokespawn <pokemon> skin=<skin>
```

Fallback si tu comando no reconoce skin=:

```mcfunction
/pokegive <pokemon> aspect=skin-<skin>
```

| Pokemon | Skin | Aspect fallback |
| --- | --- | --- |
| armarouge | skin=invencible | aspect=skin-invencible |
| golisopod | skin=invencible | aspect=skin-invencible |
| ledian | skin=invencible | aspect=skin-invencible |
| poliwrath | skin=invencible | aspect=skin-invencible |
| pikachu | skin=dj | aspect=skin-dj |
| pikachu | skin=buzzshock | aspect=skin-buzzshock |
| mimikyu | skin=afton | aspect=skin-afton |
| mimikyu | skin=fantasmatico | aspect=skin-fantasmatico |
| meloetta | skin=miku | aspect=skin-miku |
| meloetta | skin=miku2 | aspect=skin-miku2 |
| meloetta | skin=teto | aspect=skin-teto |
| snorlax | skin=teto | aspect=skin-teto |
| ditto | skin=rimuru | aspect=skin-rimuru |
| ditto | skin=goop | aspect=skin-goop |
| dragonite | skin=milim | aspect=skin-milim |
| claydol | skin=multiojos | aspect=skin-multiojos |
| great_tusk | skin=canonbolt | aspect=skin-canonbolt |
| charmander | skin=dj | aspect=skin-dj |
| azumarill | skin=dj | aspect=skin-dj |
| cramorant | skin=dj | aspect=skin-dj |
| vaporeon | skin=vaporeon | aspect=skin-vaporeon |
| gligar | skin=gligar | aspect=skin-gligar |
| gliscor | skin=gliscor | aspect=skin-gliscor |
| cyclizar | skin=koraizar | aspect=skin-koraizar |
| cyclizar | skin=miraizar | aspect=skin-miraizar |
| floette | skin=pink | aspect=skin-pink |
| magearna | skin=maid | aspect=skin-maid |
| magearna | skin=maidpink | aspect=skin-maidpink |
| bidoof | skin=bidoof | aspect=skin-bidoof |
| zoroark | skin=ben10 | aspect=skin-ben10 |
| roserade | skin=ben10 | aspect=skin-ben10 |
| snivy | skin=snivy | aspect=skin-snivy |
| greattusk | skin=canonbolt | aspect=skin-canonbolt |
| kingambit | skin=barbablanca | aspect=skin-barbablanca |
| mimikyu | skin=mimikyu | aspect=skin-mimikyu |
| absol | skin=custom | aspect=skin-custom |
| absol | skin=absol | aspect=skin-absol |
| audino | skin=invencible | aspect=skin-invencible |
| charizard | skin=metalizard | aspect=skin-metalizard |
| diancie | skin=miku | aspect=skin-miku |
| diancie | skin=movie | aspect=skin-movie |
| diancie | skin=rory | aspect=skin-rory |
| garchomp | skin=mirai | aspect=skin-mirai |
| garchomp | skin=garchomp | aspect=skin-garchomp |
| gardevoir | skin=2b | aspect=skin-2b |
| lopunny | skin=lopunny | aspect=skin-lopunny |
| lucario | skin=assasin | aspect=skin-assasin |
| lucario | skin=ryu | aspect=skin-ryu |
| lucario | skin=ben10 | aspect=skin-ben10 |
| mawile | skin=mawile | aspect=skin-mawile |
| scizor | skin=anime | aspect=skin-anime |
| incineroar | skin=incinerath | aspect=skin-incinerath |
| metagross | skin=mikulo | aspect=skin-mikulo |
| hydreigon | skin=hygigon | aspect=skin-hygigon |
| charizard | skin=cherizard | aspect=skin-cherizard |
| incineroar | skin=incinerin | aspect=skin-incinerin |
| meowscarada | skin=mewmew | aspect=skin-mewmew |
| dragapult | skin=gojo | aspect=skin-gojo |
| gallade | skin=ichigo | aspect=skin-ichigo |
| garchomp | skin=kisame | aspect=skin-kisame |
| gardevoir | skin=playa | aspect=skin-playa |
| lucario | skin=goku | aspect=skin-goku |
| greninja | skin=naruto | aspect=skin-naruto |
| lopunny | skin=playa | aspect=skin-playa |
| maushold | skin=mix | aspect=skin-mix |
| scyther | skin=zoro | aspect=skin-zoro |
| slaking | skin=saitama | aspect=skin-saitama |
| snorlax | skin=luffy | aspect=skin-luffy |
| tsareena | skin=2b | aspect=skin-2b |
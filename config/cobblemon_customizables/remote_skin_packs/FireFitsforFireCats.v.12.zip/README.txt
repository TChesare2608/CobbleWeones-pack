Thanks for downloading the pack! I hope you enjoy it as much as I do.

To change outfits, use the following items on Incineroar: 

Royal Mask Incineroar: Black Dye
Summer Incineroar: Melon Slice
Champion Incineroar: Gold Nugget
Dancer Incineroar: Note Block OR Jukebox
Pride Incineroar: Red Banner
Trans Pride Incineroar: Cyan Banner
Ace Pride Incineroar: Purple Banner
Bi Pride Incineroar: Pink Banner
Pan Pride Incineroar: Yellow Banner
Tekken Incineroar: Scaffolding
Team Skull Incineroar: Skeleton Skull
Bionicle Incineroar: Blaze Rod
Team Rocket Incineroar: Black Banner
Team Rainbow Rocket Incineroar: Ender Pearl
Team Rocket Incineroar (Anime): TNT
Rivals of Aether Incineroar: Torch
Astronaut Incineroar: Firework Rocket
Santa Incineroar: Snowball
Team Magma Incineroar: Magma Block
Team Magma Incineroar (ORAS): Lava Cookie
Detective Incineroar: Wide Lens
Cafe Incineroar: Red Wool
Mystery Dungeon Incineroar (blue): Blue Wool
Mystery Dungeon Incineroar (green): Green Wool
Band Incineroar: Throat Spray OR Metronome
El-Brave Incineroar: Muscle Band
Tiger Claw Incineroar: Turtle Scute OR Turtle Helmet
Pirate Incineroar: Spyglass
Construction Incineroar: Rocky Helmet, Safety Goggles OR Heavy-Duty Boots
Fortnite Incineroar: Luxury Ball

In addition, the following outfits are available for Litten and Torracat: 

Cafe Litten: Red Wool
Mystery Dungeon Litten (blue): Blue Wool
Mystery Dungeon Litten (green): Green Wool

Cafe Torracat: Red Wool
Mystery Dungeon Torracat (blue): Blue Wool
Mystery Dungeon Torracat (green): Green Wool

If you are on 1.6 or below, keep in mind that any items used to change outfits WILL be consumed upon use as of now. Any outfit can be removed with the shears in the 1.6 version, which will also be consumed upon use.

If the SimpleHats mod is installed, the following items are also supported: 

Champion Incineroar: Crown OR Big Crown
Astronaut Incineroar: Astronaut
Santa Incineroar: Santa Claus
Pirate Incineroar: Tricorne

Royal Mask and Band outfit designs by Ficher.
Royal Mask model, Zootopia Dancer, Pride designs/models, Tekken model, Team Skull model, Bionicle model and Rivals of Aether model by AbstractJoker.
Summer Incineroar model and outfit by RedRibbon.
Champion Incineroar model by Tin.
Team Rocket model/variants by Astolfo.
Astronaut model by SidhwinArts.
Santa and Detective models by toyota325.
Cafe and Mystery Dungeon models by hexodiax.
Team Magma classic/ORAS, Band, El-Brave and Pirate models by juano_204.
Tiger Claw model made by Archaeusdev.
Darkest Lariat animation and particle effects by Lenka.
Blaze Kick animation by DaDolphin. Particle effects by Treynami.
Construction Incineroar by XiguDJ.
Fortnite Incineroar by Rainova.

Special thanks to Orion0333 for showing me what to do and helping me bugtest everything, to Lynatic for showing me how to custom Pokedex descriptions to the various costumed forms for the 1.6 version and for getting everything supported for 1.7, to Carmendar for showing me how to fixing emissive layers and to Treynami for showing me how to implement animations with particle effects correctly.

To install the pack, make sure to copy the zip file to both the resourcepacks folder in your Minecraft instance and in the datapacks folder in your world's save data. Once installed, place the mod at the top of the load order. Placing any other resource/data pack that affects Incineroar above Fire Fits for Fire Cats in the load order will override any newly added outfits. For example, ATMxMSD needs to go below Fire Fits for Fire Cats.
This pack will work on older versions even if Minecraft says it doesn't, but you can change the pack_format number in the pack.mcmeta file if you want.

- 1 for 1.6.1 – 1.8.9
- 2 for 1.9 – 1.10.2
- 3 for 1.11 – 1.12.2
- 4 for 13 – 1.14.4
- 5 for 15 – 1.16.1
- 6 for 16.2 – 1.16.5
- 7 for 1.17 – 1.17.1
- 8 for 1.18 – 1.18.2
- 9 for 1.19 – 1.19.2
- 12 for 1.19.3
- 13 for 1.19.4
- 15 for 1.20 – 1.20.1
- 18 for 1.20.2
- 22 for 1.20.3 – 1.20.4
- 32 for 1.20.5 – 1.20.6
- 34 for 1.21 – 1.21.1
- 42 for 1.21.2 – 1.21.3
- 46 for 1.21.4
- 55 for 1.21.5

Please make sure to credit myself and all individuals involved in the creation of this pack before using it in your own datapack.
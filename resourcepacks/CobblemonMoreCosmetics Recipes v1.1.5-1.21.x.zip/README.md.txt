MoreCosmetics Recipes

Made by Archaeusdev

This is the recipe pack for a Cobblemon Cosmetics addon!

Put the zip into your datapacks folder to activate it!

Parentheses() are for recipes for shiny variants of the cosmetic

--------------------
Trainer Cosmetic Recipes:

Alola Cap 
{
Red Wool   White Wool   Red Wool
Red Wool   Big Malasada   Red Wool
Blue Wool   Blue Wool   Blue Wool
}

Baneful Fox Mask / Shiny
{
Birch Planks   N/A   Birch Planks
Birch Planks   Red Dye(Purple Dye)   Birch Planks
String   Spell Tag   String
}

Lucario Hood / Shiny
{
Light Blue Wool(Yellow Wool)   N/A   Light Blue Wool(Yellow Wool)
Gray Wool(Cyan Wool)   Black Belt   Gray Wool(Cyan Wool)
Light Blue Wool(Yellow Wool)   Light Blue Wool(Yellow Wool)   Light Blue Wool(Yellow Wool)
}

Mimikyu Mask / Shiny
{
Yellow Wool(White Wool)   N/A   Yellow Wool(White Wool)
Black Wool   Spell Tag   Black Wool
Orange Wool(Gray Wool)   Yellow Wool(White Wool)   Orange Wool(Gray Wool)
}

Umbreon Mask / Shiny
{
Black Wool   N/A   Black Wool
Yellow Wool(Light Blue Wool)   Black Wool   Yellow Wool(Light Blue Wool)
Red Dye(Yellow Dye)   Black Wool   Red Wool(Yellow Wool)
}

Yellow Hat
{
N/A   Yellow Wool   N/A
Yellow Wool   Light Ball   Yellow Wool
N/A   N/A   N/A
}

Eevee Mask / Shiny
{
Brown Wool(White Wool)   N/A   Brown Wool(White Wool)
Brown Wool(White Wool)   Brown Wool(White Wool)   Brown Wool(White Wool)
String   Silk Scarf   String


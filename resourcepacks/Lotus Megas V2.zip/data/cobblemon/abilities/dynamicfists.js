{
    onSourceDamagingHit(damage, target, source, move) {
        if (target.hasAbility("shielddust") || target.hasItem("covertcloak"))
            return;

        if (this.checkMoveMakesContact(move, target, source)) {
            if (this.randomChance(5, 10) && !target.volatiles["confusion"]) {
                target.addVolatile("confusion");
            }
        }
    },
    flags: {},
    name: "Dynamic Fists",
    rating: 3,
    num: 1001
}
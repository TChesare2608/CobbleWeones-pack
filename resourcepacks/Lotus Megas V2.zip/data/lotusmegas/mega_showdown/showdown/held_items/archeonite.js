{
  name: "Archeonite",
  spritenum: 677,
  megaStone: "Archeops-Mega",
  megaEvolves: ["Archeops"],
  itemUser: ["Archeops"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
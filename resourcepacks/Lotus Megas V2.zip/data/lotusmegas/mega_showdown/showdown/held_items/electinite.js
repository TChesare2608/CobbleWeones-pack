{
  name: "Electinite",
  spritenum: 677,
  megaStone: "Electivire-Mega",
  megaEvolves: ["Electivire"],
  itemUser: ["Electivire"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
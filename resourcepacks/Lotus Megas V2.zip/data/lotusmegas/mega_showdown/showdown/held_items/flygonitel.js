{
  name: "Flygonite L",
  spritenum: 677,
  megaStone: "Flygon-Mega-L",
  megaEvolves: ["Flygon"],
  itemUser: ["Flygon"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 3,
  isNonstandard: "Past"
}
{
  name: "Gardevoirite Z",
  spritenum: 677,
  megaStone: "Gardevoir-Mega-Z",
  megaEvolves: ["Gardevoir"],
  itemUser: ["Gardevoir"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 3,
  isNonstandard: "Past"
}
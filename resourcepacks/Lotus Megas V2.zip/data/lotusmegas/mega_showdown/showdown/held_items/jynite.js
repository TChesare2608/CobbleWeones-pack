{
  name: "Jynite",
  spritenum: 677,
  megaStone: "Jynx-Mega",
  megaEvolves: ["Jynx"],
  itemUser: ["Jynx"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 1,
  isNonstandard: "Past"
}
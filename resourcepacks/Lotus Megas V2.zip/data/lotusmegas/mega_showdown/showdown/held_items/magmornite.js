{
  name: "Magmornite",
  spritenum: 677,
  megaStone: "Magmortar-Mega",
  megaEvolves: ["Magmortar"],
  itemUser: ["Magmortar"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 4,
  isNonstandard: "Past"
}
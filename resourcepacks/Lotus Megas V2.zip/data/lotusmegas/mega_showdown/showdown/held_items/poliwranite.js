{
  name: "Poliwranite",
  spritenum: 677,
  megaStone: "Poliwrath-Mega",
  megaEvolves: ["Poliwrath"],
  itemUser: ["Poliwrath"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
{
  name: "Tropinite",
  spritenum: 677,
  megaStone: "Tropius-Mega",
  megaEvolves: ["Tropius"],
  itemUser: ["Tropius"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
{
  name: "Typhlonite",
  spritenum: 677,
  megaStone: "Typhlosion-Mega",
  megaEvolves: ["Typhlosion"],
  itemUser: ["Typhlosion"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
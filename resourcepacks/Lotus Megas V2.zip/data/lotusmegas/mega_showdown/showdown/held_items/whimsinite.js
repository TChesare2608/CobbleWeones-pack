{
  name: "Whimsinite",
  spritenum: 677,
  megaStone: "Whimsicott-Mega",
  megaEvolves: ["Whimsicott"],
  itemUser: ["Whimsicott"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}
{
  name: "Zoroarnite",
  spritenum: 677,
  megaStone: "Zoroark-Mega",
  megaEvolves: ["Zoroark"],
  itemUser: ["Zoroark"],
  onTakeItem(item, source) {
    if (item.megaEvolves.includes(source.baseSpecies.baseSpecies)) return false;
    return true;
  },
  num: -999,
  gen: 5,
  isNonstandard: "Past"
}